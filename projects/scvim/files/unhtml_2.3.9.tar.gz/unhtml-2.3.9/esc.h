extern int m_putchar(int);
